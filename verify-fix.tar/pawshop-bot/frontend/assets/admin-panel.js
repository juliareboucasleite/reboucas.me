const state = {
  guild: null,
  stats: null,
  channels: [],
  imageAssets: [],
  settings: null,
  products: [],
  logs: [],
  me: null,
};

const refs = {
  me: document.getElementById('me'),
  guildMeta: document.getElementById('guild-meta'),
  overviewStats: document.getElementById('overview-stats'),
  list: document.getElementById('lista'),
  logsList: document.getElementById('logs-list'),
  refreshDashboard: document.getElementById('refresh-dashboard'),
  productForm: document.getElementById('form-novo'),
  settingsForm: document.getElementById('settings-form'),
  verifyForm: document.getElementById('verify-form'),
  verifyPostForm: document.getElementById('verify-post-form'),
  roleMultiSelect: document.querySelector('[data-role-multiselect]'),
  supportHelpForm: document.getElementById('support-help-form'),
  supportInfoForm: document.getElementById('support-info-form'),
  embedForm: document.getElementById('embed-form'),
  previewWelcome: document.getElementById('preview-welcome'),
  previewGoodbye: document.getElementById('preview-goodbye'),
  welcomeCard: document.getElementById('welcome-preview-card'),
  goodbyeCard: document.getElementById('goodbye-preview-card'),
};

const DEFAULT_IMAGE_ASSETS = [
  { value: 'Welcome.png', label: 'Welcome.png' },
  { value: 'byebye.png', label: 'byebye.png' },
  { value: 'Logo.png', label: 'Logo.png' },
  { value: 'prices.png', label: 'prices.png' },
];
const DEFAULT_VERIFY_CHANNEL_ID = '1500443369074065449';

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function resolveAssetUrl(pathname) {
  return new URL(String(pathname || ''), document.baseURI).toString();
}

async function requestJson(url, options = {}) {
  const resolvedUrl = String(url || '');
  const fetchUrl = new URL(resolvedUrl, document.baseURI).toString();

  const response = await fetch(fetchUrl, {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      ...(options.headers ?? {}),
    },
    ...options,
  });

  if (response.redirected && /\/login(\?|$)/.test(response.url)) {
    window.location.href = response.url;
    throw new Error('Sessão expirada. Redirecionando para login...');
  }

  const isJson = (response.headers.get('content-type') || '').includes('application/json');
  const payload = isJson ? await response.json() : await response.text();

  if (!response.ok) {
    const message = typeof payload === 'object' ? payload.erro || 'Falha na requisição.' : payload;
    throw new Error(message);
  }

  if (!isJson) {
    throw new Error('Resposta inesperada do servidor (não-JSON). Faça login novamente.');
  }

  return payload;
}

function notify(message, isError = false) {
  let node = document.getElementById('admin-toast');
  if (!node) {
    node = document.createElement('div');
    node.id = 'admin-toast';
    node.className = 'admin-toast';
    document.body.appendChild(node);
  }

  node.textContent = message;
  node.dataset.error = isError ? 'true' : 'false';
  node.classList.add('is-visible');
  clearTimeout(node._timer);
  node._timer = setTimeout(() => node.classList.remove('is-visible'), 2600);
}

function channelLabel(channelId) {
  const channel = state.channels.find((item) => item.id === channelId);
  return channel ? `#${channel.name}` : '#nao-configurado';
}

function renderOverview() {
  const stats = state.stats || { products: 0, channels: 0, logs: 0 };
  const guild = state.guild;

  refs.overviewStats.innerHTML = [
    {
      label: 'Servidor',
      value: guild?.name || 'Desconectado',
      detail: guild ? `${guild.memberCount || 0} membros` : 'Sem guild configurada',
    },
    {
      label: 'Produtos',
      value: stats.products,
      detail: 'itens cadastrados',
    },
    {
      label: 'Canais',
      value: stats.channels,
      detail: 'canais disponíveis no painel',
    },
    {
      label: 'Logs',
      value: stats.logs,
      detail: 'eventos recentes',
    },
  ]
    .map(
      (card) => `
        <article class="stat-card">
          <span>${escapeHtml(card.label)}</span>
          <strong>${escapeHtml(card.value)}</strong>
          <small>${escapeHtml(card.detail)}</small>
        </article>`,
    )
    .join('');

  refs.guildMeta.innerHTML = guild
    ? `
      <div class="guild-meta">
        ${guild.iconUrl ? `<img src="${guild.iconUrl}" alt="${escapeHtml(guild.name)}" />` : ''}
        <div>
          <strong>${escapeHtml(guild.name)}</strong>
          <p>${guild.memberCount || 0} membros · ${guild.roleCount || 0} cargos</p>
        </div>
      </div>`
    : '<p>Nenhuma guild conectada.</p>';
}

function renderProducts() {
  if (!state.products.length) {
    refs.list.innerHTML = '<article class="card" data-empty>Nenhum produto cadastrado ainda.</article>';
    return;
  }

  refs.list.innerHTML = state.products
    .map(
      (product) => `
        <article class="card">
          ${product.imagem ? `<img src="${escapeHtml(product.imagem)}" alt="${escapeHtml(product.nome)}" loading="lazy" />` : ''}
          <span class="cat">${escapeHtml(product.categoria)}</span>
          <h3>${escapeHtml(product.nome)}</h3>
          <p>${escapeHtml(product.descricao || 'Sem descrição curta.')}</p>
          <p class="preco">${escapeHtml(product.preco)} ${escapeHtml(product.moeda)}</p>
          <button type="button" data-del="${escapeHtml(product.id)}">Remover</button>
        </article>`,
    )
    .join('');

  refs.list.querySelectorAll('[data-del]').forEach((button) => {
    button.addEventListener('click', async () => {
      if (!confirm('Remover este produto do catálogo?')) return;
      try {
        await requestJson(`api/admin/produtos/${button.dataset.del}`, { method: 'DELETE' });
        notify('Produto removido.');
        await loadDashboard();
      } catch (error) {
        notify(error.message, true);
      }
    });
  });
}

function renderLogs() {
  if (!state.logs.length) {
    refs.logsList.innerHTML = '<p class="empty-copy">Nenhum log ainda.</p>';
    return;
  }

  refs.logsList.innerHTML = state.logs
    .map((log) => {
      const when = new Date(log.createdAt).toLocaleString('pt-BR');
      const actor = log.actor?.username ? `${log.actor.username}${log.actor.id ? ` · ${log.actor.id}` : ''}` : 'sistema';

      return `
        <article class="log-item">
          <div class="log-item__top">
            <strong>${escapeHtml(log.title || log.type || 'Evento')}</strong>
            <span>${escapeHtml(when)}</span>
          </div>
          <p>${escapeHtml(log.message || '')}</p>
          <div class="log-item__meta">
            <span>${escapeHtml(log.source || 'painel')}</span>
            <span>${escapeHtml(actor)}</span>
          </div>
        </article>`;
    })
    .join('');
}

function fillChannelSelects() {
  const selects = document.querySelectorAll('[data-channel-select]');
  const options = [
    '<option value="">Selecionar canal</option>',
    ...state.channels.map(
      (channel) => `<option value="${escapeHtml(channel.id)}">#${escapeHtml(channel.name)}</option>`,
    ),
  ].join('');

  selects.forEach((select) => {
    const previous = select.value;
    select.innerHTML = options;
    if (previous) select.value = previous;
  });
}

function renderImagePickerFor(select, assets) {
  if (!select) return;
  const id = select.dataset.pickerId || `img-picker-${Math.random().toString(36).slice(2, 8)}`;
  select.dataset.pickerId = id;

  const anchor = select.closest('label') || select;
  let picker = document.querySelector(`[data-image-asset-picker="${id}"]`);
  if (!picker) {
    picker = document.createElement('div');
    picker.className = 'image-picker';
    picker.dataset.imageAssetPicker = id;
    anchor.insertAdjacentElement('afterend', picker);
  }

  const current = select.value || '';
  const items = [
    { value: '', label: 'Sem imagem', isEmpty: true },
    ...(assets || []),
  ];

  picker.innerHTML = items
    .map((asset) => {
      const isSelected = (asset.value || '') === current;
      const thumb = asset.isEmpty
        ? '<span class="image-picker__none" aria-hidden="true">∅</span>'
        : `<img src="${escapeHtml(resolveAssetUrl(`images/${encodeURIComponent(asset.value)}`))}" alt="${escapeHtml(asset.label)}" loading="lazy" />`;
      return `
        <button
          type="button"
          class="image-picker__item${isSelected ? ' is-selected' : ''}"
          data-asset-value="${escapeHtml(asset.value)}"
          title="${escapeHtml(asset.label)}"
        >
          ${thumb}
          <span class="image-picker__label">${escapeHtml(asset.label)}</span>
        </button>`;
    })
    .join('');

  picker.querySelectorAll('[data-asset-value]').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const value = btn.dataset.assetValue || '';
      select.value = value;
      select.dispatchEvent(new Event('change', { bubbles: true }));
      picker.querySelectorAll('.image-picker__item').forEach((it) => it.classList.remove('is-selected'));
      btn.classList.add('is-selected');
    });
  });

  if (!select.dataset.pickerSync) {
    select.dataset.pickerSync = '1';
    select.addEventListener('change', () => {
      const value = select.value || '';
      picker.querySelectorAll('.image-picker__item').forEach((it) => {
        it.classList.toggle('is-selected', (it.dataset.assetValue || '') === value);
      });
    });
  }
}

function getMergedImageAssets() {
  const assets = [...DEFAULT_IMAGE_ASSETS, ...(state.imageAssets || [])];
  return assets.filter((asset, index, array) =>
    index === array.findIndex((item) => item.value === asset.value),
  );
}

async function fillImageAssetSelects() {
  try {
    const uniqueAssets = getMergedImageAssets();
    const options = ['<option value="">Sem imagem</option>']
      .concat(uniqueAssets.map((asset) => `<option value="${escapeHtml(asset.value)}">${escapeHtml(asset.label)}</option>`))
      .join('');

    document.querySelectorAll('[data-image-asset-select]').forEach((select) => {
      const previous = select.value;
      select.innerHTML = options;
      if (previous) select.value = previous;
      renderImagePickerFor(select, uniqueAssets);
    });
  } catch (error) {
    console.warn('[admin] fillImageAssetSelects failed', error);
  }
}

window.__pawshopImagePicker = {
  render: renderImagePickerFor,
  getAssets: getMergedImageAssets,
};

function populateSettingsForm() {
  const settings = state.settings;
  if (!settings) return;

  const form = refs.settingsForm;
  form.welcomeChannelId.value = settings.channels?.welcomeChannelId || '';
  form.goodbyeChannelId.value = settings.channels?.goodbyeChannelId || '';
  form.logsChannelId.value = settings.channels?.logsChannelId || '';
  form.ticketChannelId.value = settings.channels?.ticketChannelId || '';
  form.pricesChannelId.value = settings.channels?.pricesChannelId || '';
  form.infoChannelId.value = settings.channels?.infoChannelId || '';
  form.rulesChannelId.value = settings.channels?.rulesChannelId || '';
  form.embedChannelId.value = settings.channels?.embedChannelId || '';

  form.accentColor.value = settings.appearance?.accentColor || '#f4cfe0';
  form.authorName.value = settings.appearance?.authorName || '/pawshop';

  form.welcomeEnabled.checked = Boolean(settings.welcome?.enabled);
  form.goodbyeEnabled.checked = Boolean(settings.goodbye?.enabled);

  form.welcomeTitle.value = settings.welcome?.title || '';
  form.welcomeIntro.value = settings.welcome?.intro || '';
  form.welcomeVerifyLine.value = settings.welcome?.verifyLine || '';
  form.welcomeMemberCountText.value = settings.welcome?.memberCountText || '';

  form.goodbyeTitle.value = settings.goodbye?.title || '';
  form.goodbyeIntro.value = settings.goodbye?.intro || '';
  form.goodbyeOutro.value = settings.goodbye?.outro || '';
  form.goodbyeMemberCountText.value = settings.goodbye?.memberCountText || '';

  const helpForm = refs.supportHelpForm;
  if (helpForm) {
    helpForm.title.value = settings.support?.help?.title || 'Help';
    helpForm.description.value = settings.support?.help?.description || '';
    helpForm.footer.value = settings.support?.help?.footer || 'Powered by tickets.bot';
    helpForm.categoryId.value = settings.support?.help?.categoryId || '';
    helpForm.channelId.value = settings.support?.help?.channelId || '';
  }

  const infoForm = refs.supportInfoForm;
  if (infoForm) {
    infoForm.title.value = settings.support?.info?.title || 'Information';
    infoForm.description.value = settings.support?.info?.description || '';
    infoForm.footer.value = settings.support?.info?.footer || 'Powered by tickets.bot';
    infoForm.categoryId.value = settings.support?.info?.categoryId || '';
    infoForm.channelId.value = settings.support?.info?.channelId || '';
  }

  const verifyForm = refs.verifyForm;
  if (verifyForm) {
    verifyForm.title.value = settings.verification?.title || 'verify yourself';
    verifyForm.description.value = settings.verification?.description || '';
    verifyForm.buttonLabel.value = settings.verification?.buttonLabel || 'verify';

    const roleIds = settings.verification?.roleIds || [];
    const roleContainer = refs.roleMultiSelect;
    if (roleContainer) {
      roleContainer.querySelectorAll('input[type="checkbox"][data-role-id]').forEach((checkbox) => {
        checkbox.checked = roleIds.includes(checkbox.value);
      });
    }
  }

  if (refs.verifyPostForm) {
    refs.verifyPostForm.channelId.value =
      settings.verification?.channelId || DEFAULT_VERIFY_CHANNEL_ID;
  }

  refs.embedForm.channelId.value = settings.channels?.embedChannelId || '';
  refs.embedForm.color.value = settings.appearance?.accentColor || '#f4cfe0';

  renderPreviewCards();
}

function getSettingsFromForm() {
  const form = refs.settingsForm;

  return {
    channels: {
      welcomeChannelId: form.welcomeChannelId.value,
      goodbyeChannelId: form.goodbyeChannelId.value,
      logsChannelId: form.logsChannelId.value,
      ticketChannelId: form.ticketChannelId.value,
      pricesChannelId: form.pricesChannelId.value,
      infoChannelId: form.infoChannelId.value,
      rulesChannelId: form.rulesChannelId.value,
      embedChannelId: form.embedChannelId.value,
    },
    welcome: {
      enabled: form.welcomeEnabled.checked,
      title: form.welcomeTitle.value,
      intro: form.welcomeIntro.value,
      verifyLine: form.welcomeVerifyLine.value,
      memberCountText: form.welcomeMemberCountText.value,
    },
    goodbye: {
      enabled: form.goodbyeEnabled.checked,
      title: form.goodbyeTitle.value,
      intro: form.goodbyeIntro.value,
      outro: form.goodbyeOutro.value,
      memberCountText: form.goodbyeMemberCountText.value,
    },
    support: refs.supportHelpForm || refs.supportInfoForm
      ? {
          help: refs.supportHelpForm
            ? {
                title: refs.supportHelpForm.title.value,
                description: refs.supportHelpForm.description.value,
                footer: refs.supportHelpForm.footer.value,
                buttonLabel: refs.supportHelpForm.title.value || 'Open help ticket',
                categoryId: refs.supportHelpForm.categoryId.value,
                channelId: refs.supportHelpForm.channelId.value,
              }
            : state.settings?.support?.help || {},
          info: refs.supportInfoForm
            ? {
                title: refs.supportInfoForm.title.value,
                description: refs.supportInfoForm.description.value,
                footer: refs.supportInfoForm.footer.value,
                buttonLabel: refs.supportInfoForm.title.value || 'Open information ticket',
                categoryId: refs.supportInfoForm.categoryId.value,
                channelId: refs.supportInfoForm.channelId.value,
              }
            : state.settings?.support?.info || {},
        }
      : state.settings?.support || {},
    verification: state.settings?.verification || {},
    appearance: {
      accentColor: form.accentColor.value,
      authorName: form.authorName.value,
    },
  };
}

function replaceTokens(text, kind) {
  const settings = getSettingsFromForm();
  const memberCount = state.guild?.memberCount || 0;
  const replacements = {
    '{user}': kind === 'goodbye' ? '@eutesy' : '@julia',
    '{server}': state.guild?.name || 'Pawshop',
    '{memberCount}': String(memberCount),
    '{rulesChannel}': channelLabel(settings.channels.rulesChannelId),
    '{ticketChannel}': channelLabel(settings.channels.ticketChannelId),
    '{pricesChannel}': channelLabel(settings.channels.pricesChannelId),
    '{infoChannel}': channelLabel(settings.channels.infoChannelId),
  };

  return Object.entries(replacements).reduce(
    (acc, [token, value]) => acc.replaceAll(token, value),
    String(text || ''),
  );
}

function renderPreviewCards() {
  const settings = getSettingsFromForm();
  const author = settings.appearance.authorName || '/pawshop';

  refs.welcomeCard.innerHTML = `
    <div class="discord-card__header">
      <div>
        <strong>${escapeHtml(author)}</strong>
        <p>${escapeHtml(replaceTokens(settings.welcome.title, 'welcome'))}</p>
      </div>
      <img src="${escapeHtml(resolveAssetUrl('images/Logo.png'))}" alt="Logo Pawshop" class="discord-card__thumb" />
    </div>
    <div class="discord-card__body">
      <p>${escapeHtml(replaceTokens(settings.welcome.intro, 'welcome'))}</p>
      <p>🍼 ${escapeHtml(channelLabel(settings.channels.ticketChannelId))}</p>
      <p>🍼 ${escapeHtml(channelLabel(settings.channels.pricesChannelId))}</p>
      <p>🍼 ${escapeHtml(channelLabel(settings.channels.infoChannelId))}</p>
      <p>${escapeHtml(replaceTokens(settings.welcome.verifyLine, 'welcome'))}</p>
      <img src="${escapeHtml(resolveAssetUrl('images/Welcome.png'))}" alt="Preview welcome" class="discord-card__banner" />
      <small>${escapeHtml(replaceTokens(settings.welcome.memberCountText, 'welcome'))}</small>
    </div>`;

  refs.goodbyeCard.innerHTML = `
    <div class="discord-card__header">
      <div>
        <strong>${escapeHtml(author)}</strong>
        <p>${escapeHtml(replaceTokens(settings.goodbye.title, 'goodbye'))}</p>
      </div>
      <img src="${escapeHtml(resolveAssetUrl('images/Logo.png'))}" alt="Logo Pawshop" class="discord-card__thumb" />
    </div>
    <div class="discord-card__body">
      <p>${escapeHtml(replaceTokens(settings.goodbye.intro, 'goodbye'))}</p>
      <p>${escapeHtml(replaceTokens(settings.goodbye.outro, 'goodbye'))}</p>
      <img src="${escapeHtml(resolveAssetUrl('images/byebye.png'))}" alt="Preview bye" class="discord-card__banner discord-card__banner--small" />
      <small>${escapeHtml(replaceTokens(settings.goodbye.memberCountText, 'goodbye'))}</small>
    </div>`;
}

function showBannerErrors(errors) {
  let banner = document.getElementById('admin-error-banner');
  if (!errors.length) {
    if (banner) banner.remove();
    return;
  }
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'admin-error-banner';
    banner.style.cssText =
      'position:sticky;top:0;z-index:50;padding:0.7rem 1rem;background:#ffe1ec;color:#922;border-bottom:1px solid #f3a;font:13px/1.4 Arial,sans-serif;';
    document.body.prepend(banner);
  }
  banner.innerHTML =
    '<strong>Falhas ao carregar:</strong> ' +
    errors.map((e) => `<span>${escapeHtml(e)}</span>`).join(' · ');
}

async function loadCurrentUser() {
  try {
    state.me = await requestJson('api/me');
    refs.me.textContent = state.me ? `★ ${state.me.global_name ?? state.me.username}` : '—';
  } catch (error) {
    refs.me.textContent = '—';
    console.warn('[admin] loadCurrentUser failed:', error);
  }
}

async function loadDashboard() {
  const errors = [];

  try {
    const payload = await requestJson('api/admin/dashboard');
    console.debug('[admin] dashboard payload:', payload);
    state.guild = payload.guild ?? null;
    state.stats = payload.stats ?? null;
    state.channels = Array.isArray(payload.channels) ? payload.channels : [];
    state.imageAssets = Array.isArray(payload.images) ? payload.images : [];
    state.settings = payload.settings ?? null;
    state.logs = Array.isArray(payload.logs) ? payload.logs : [];
  } catch (error) {
    console.error('[admin] dashboard failed:', error);
    errors.push(`dashboard: ${error.message}`);
  }

  try {
    const produtos = await requestJson('api/admin/produtos');
    state.products = Array.isArray(produtos) ? produtos : [];
  } catch (error) {
    console.error('[admin] produtos failed:', error);
    state.products = [];
    errors.push(`produtos: ${error.message}`);
  }

  try { fillChannelSelects(); } catch (e) { errors.push(`canais: ${e.message}`); }
  try { await fillImageAssetSelects(); } catch (e) { errors.push(`imagens: ${e.message}`); }
  try { renderOverview(); } catch (e) { errors.push(`overview: ${e.message}`); }
  try { populateSettingsForm(); } catch (e) { errors.push(`settings: ${e.message}`); }
  try { renderProducts(); } catch (e) { errors.push(`products render: ${e.message}`); }
  try { renderLogs(); } catch (e) { errors.push(`logs render: ${e.message}`); }

  showBannerErrors(errors);
}

refs.refreshDashboard.addEventListener('click', async () => {
  try {
    await loadDashboard();
    notify('Painel atualizado.');
  } catch (error) {
    notify(error.message, true);
  }
});

refs.productForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const formData = Object.fromEntries(new FormData(event.currentTarget).entries());
    await requestJson('api/admin/produtos', {
      method: 'POST',
      body: JSON.stringify(formData),
    });
    event.currentTarget.reset();
    notify('Produto adicionado ao catálogo.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.settingsForm.addEventListener('input', renderPreviewCards);
refs.settingsForm.addEventListener('change', renderPreviewCards);

refs.supportHelpForm?.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const payload = getSettingsFromForm();
    state.settings = await requestJson('api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    const supportChannelId = refs.supportHelpForm.channelId.value;
    if (supportChannelId) {
      await requestJson('api/admin/support/post', {
        method: 'POST',
        body: JSON.stringify({ channelId: supportChannelId, kind: 'help' }),
      });
    }
    notify('Help salvo.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.supportInfoForm?.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const payload = getSettingsFromForm();
    state.settings = await requestJson('api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    const supportChannelId = refs.supportInfoForm.channelId.value;
    if (supportChannelId) {
      await requestJson('api/admin/support/post', {
        method: 'POST',
        body: JSON.stringify({ channelId: supportChannelId, kind: 'info' }),
      });
    }
    notify('Information salvo.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.settingsForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const payload = getSettingsFromForm();
    state.settings = await requestJson('api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    notify('Configurações salvas.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.embedForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const formData = new FormData(event.currentTarget);
    await requestJson('api/admin/embeds/send', {
      method: 'POST',
      body: JSON.stringify({
        channelId: formData.get('channelId'),
        title: formData.get('title'),
        description: formData.get('description'),
        footer: formData.get('footer'),
        color: formData.get('color'),
        imageAsset: formData.get('imageAsset'),
        useLogo: formData.get('useLogo') === 'on',
      }),
    });
    notify('Embed enviado.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.previewWelcome.addEventListener('click', async () => {
  try {
    await requestJson('api/admin/welcome/preview', { method: 'POST', body: JSON.stringify({}) });
    notify('Preview de welcome enviado.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.previewGoodbye.addEventListener('click', async () => {
  try {
    await requestJson('api/admin/goodbye/preview', { method: 'POST', body: JSON.stringify({}) });
    notify('Preview de bye enviado.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.verifyForm?.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const form = refs.verifyForm;
    const roleIds = Array.from(
      refs.roleMultiSelect?.querySelectorAll('input[type="checkbox"][data-role-id]:checked') || [],
    ).map((checkbox) => checkbox.value);

    if (roleIds.length === 0) {
      throw new Error('Selecione ao menos um cargo.');
    }

    const payload = getSettingsFromForm();
    payload.verification = {
      roleIds,
      title: form.title.value,
      description: form.description.value,
      buttonLabel: form.buttonLabel.value,
    };

    state.settings = await requestJson('api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    notify('Verificação salva.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

refs.verifyPostForm?.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const channelId = refs.verifyPostForm.channelId.value;
    if (!channelId) throw new Error('Selecione um canal.');

    await requestJson('api/admin/verify/post', {
      method: 'POST',
      body: JSON.stringify({ channelId }),
    });

    notify('Painel de verificação postado.');
    await loadDashboard();
  } catch (error) {
    notify(error.message, true);
  }
});

(async () => {
  try {
    await Promise.all([loadCurrentUser(), loadDashboard()]);
  } catch (error) {
    notify(error.message, true);
  }
})();
