/* ============================================================
   admin-features.js
   gerencia as seções: verify · precos · sorteios · forum
   roda DEPOIS do admin-panel.js (que carrega channels/settings/etc)
   ============================================================ */
(function () {
  'use strict';

  const DEFAULT_IMAGE_ASSETS = [
    { value: 'Welcome.png', label: 'Welcome.png' },
    { value: 'byebye.png', label: 'byebye.png' },
    { value: 'Logo.png', label: 'Logo.png' },
    { value: 'prices.png', label: 'prices.png' },
  ];

  function $(sel, ctx = document) { return ctx.querySelector(sel); }
  function $$(sel, ctx = document) { return [...ctx.querySelectorAll(sel)]; }

  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, (m) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[m]));
  }

  function resolveAssetUrl(pathname) {
    return new URL(String(pathname || ''), document.baseURI).toString();
  }

  async function api(url, options = {}) {
    const resolvedUrl = String(url || '');
    const fetchUrl = new URL(resolvedUrl, document.baseURI).toString();

    const r = await fetch(fetchUrl, {
      headers: { Accept: 'application/json', 'Content-Type': 'application/json', ...(options.headers ?? {}) },
      ...options,
    });
    if (r.redirected && /\/login(\?|$)/.test(r.url)) {
      window.location.href = r.url;
      throw new Error('sessão expirada');
    }
    const isJson = (r.headers.get('content-type') || '').includes('application/json');
    const data = isJson ? await r.json() : await r.text();
    if (!r.ok) throw new Error(typeof data === 'object' ? data.erro || 'falha' : data);
    if (!isJson) throw new Error('resposta inesperada (não-JSON). faça login novamente.');
    return data;
  }

  async function popularImageAssets() {
    try {
      const assetsFromApi = await api('api/admin/dashboard').then((d) => d.images || []);
      console.debug('[features] assetsFromApi:', assetsFromApi);
      const assets = [...DEFAULT_IMAGE_ASSETS, ...assetsFromApi].filter((asset, index, array) =>
        index === array.findIndex((item) => item.value === asset.value),
      );
      const options = ['<option value="">Sem imagem</option>']
        .concat(assets.map((asset) => `<option value="${escapeHtml(asset.value)}">${escapeHtml(asset.label)}</option>`))
        .join('');

      $$('select[data-image-asset-select]').forEach((sel) => {
        const current = sel.value;
        sel.innerHTML = options;
        if (current) sel.value = current;
        if (window.__pawshopImagePicker?.render) {
          window.__pawshopImagePicker.render(sel, assets);
        }
      });
    } catch (err) {
      console.warn('[features] popular images falhou', err);
    }
  }

  function toast(msg, isError = false) {
    let node = document.getElementById('admin-toast');
    if (!node) {
      node = document.createElement('div');
      node.id = 'admin-toast';
      node.className = 'admin-toast';
      document.body.appendChild(node);
    }
    node.textContent = msg;
    node.dataset.error = isError ? 'true' : 'false';
    node.classList.add('is-visible');
    clearTimeout(node._t);
    node._t = setTimeout(() => node.classList.remove('is-visible'), 2600);
  }

  // ---------- popula selects compartilhados ----------
  async function popularSelects() {
    await popularImageAssets();
    try {
      const [channels, roles, categories, forums] = await Promise.all([
        api('api/admin/dashboard').then((d) => d.channels || []),
        api('api/admin/roles'),
        api('api/admin/categories'),
        api('api/admin/forum/channels'),
      ]);

      // canais de texto
      $$('select[data-channel-select]').forEach((sel) => {
        const cur = sel.value;
        sel.innerHTML =
          '<option value="">— escolha o canal —</option>' +
          channels.map((c) => `<option value="${c.id}">#${escapeHtml(c.name)}</option>`).join('');
        if (cur) sel.value = cur;
      });

      // cargos
      $$('div[data-role-multiselect]').forEach((container) => {
        const selected = new Set(
          Array.from(container.querySelectorAll('input[type="checkbox"][data-role-id]:checked')).map((input) => input.value),
        );

        container.innerHTML = roles
          .map(
            (role) => `
              <label class="checkbox-row checkbox-row--stacked">
                <input type="checkbox" data-role-id value="${escapeHtml(role.id)}" ${selected.has(role.id) ? 'checked' : ''} />
                <span>${escapeHtml(role.name)}</span>
              </label>`,
          )
          .join('');
      });

      $$('select[data-role-select]').forEach((sel) => {
        const cur = sel.hasAttribute('multiple') 
          ? Array.from(sel.options).filter(opt => opt.selected).map(opt => opt.value)
          : sel.value;
        sel.innerHTML =
          '<option value="">— escolha o cargo —</option>' +
          roles.map((r) => `<option value="${r.id}">${escapeHtml(r.name)}</option>`).join('');
        
        if (sel.hasAttribute('multiple')) {
          const curArr = Array.isArray(cur) ? cur : [cur].filter(Boolean);
          Array.from(sel.options).forEach(opt => {
            opt.selected = curArr.includes(opt.value);
          });
        } else if (cur) {
          sel.value = cur;
        }
      });

      // categorias
      $$('select[data-category-select]').forEach((sel) => {
        const cur = sel.value;
        sel.innerHTML =
          '<option value="">— sem categoria —</option>' +
          categories.map((c) => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
        if (cur) sel.value = cur;
      });

      // foruns
      $$('select[data-forum-select]').forEach((sel) => {
        const cur = sel.value;
        sel.innerHTML =
          '<option value="">— escolha o fórum —</option>' +
          forums.map((f) => `<option value="${f.id}">${escapeHtml(f.name)}</option>`).join('');
        if (cur) sel.value = cur;
      });
    } catch (err) {
      console.warn('[features] popular selects falhou', err);
    }
  }

  // ---------- VERIFICAÇÃO ----------
  function setupVerify() {
    const form = $('#verify-form');
    if (!form) return;
    const postForm = $('#verify-post-form');
    api('api/admin/settings').then((s) => {
      if (postForm?.elements?.channelId) {
        postForm.elements.channelId.value =
          s.verification?.channelId ?? '1500443369074065449';
      }
    });
  }

  // ---------- PRECOS ----------
  function setupPrecos() {
    const form = $('#precos-form');
    const postForm = $('#precos-post-form');
    const methodsBox = $('#precos-methods');
    if (!form) return;

    const PAYMENTS = ['robux', 'paypal', 'wise', 'stripe'];

    function renderMethods(methods) {
      methodsBox.innerHTML = PAYMENTS.map((k) => {
        const m = methods?.[k] ?? { enabled: true, label: k };
        return `
          <label>
            <input type="checkbox" name="m_${k}" ${m.enabled === false ? '' : 'checked'} />
            <input type="text" name="label_${k}" value="${escapeHtml(m.label || k)}" placeholder="${k}" style="width:120px;margin-left:6px;" />
          </label>`;
      }).join('');
    }

    api('api/admin/settings').then((s) => {
      const p = s.pricing ?? {};
      form.elements.ticketCategoryId.value = p.ticketCategoryId ?? '';
      form.elements.title.value = p.title ?? '';
      form.elements.description.value = p.description ?? '';
      if (form.elements.imageAsset) {
        form.elements.imageAsset.value = p.imageAsset ?? '';
        form.elements.imageAsset.dispatchEvent(new Event('change', { bubbles: true }));
      }
      if (form.elements.imageUrl) form.elements.imageUrl.value = p.imageUrl ?? '';
      renderMethods(p.methods);
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const methods = {};
      PAYMENTS.forEach((k) => {
        methods[k] = {
          enabled: fd.has(`m_${k}`),
          label: String(fd.get(`label_${k}`) ?? '').trim() || k,
        };
      });
      try {
        const atual = await api('api/admin/settings');
        await api('api/admin/settings', {
          method: 'PUT',
          body: JSON.stringify({
            ...atual,
            pricing: {
              ticketCategoryId: fd.get('ticketCategoryId'),
              title: fd.get('title'),
              description: fd.get('description'),
              imageAsset: fd.get('imageAsset'),
              imageUrl: fd.get('imageUrl'),
              imageAttachment: atual.pricing?.imageAttachment ?? null,
              methods,
            },
          }),
        });
        toast('preços salvos ✦');
      } catch (err) { toast(err.message, true); }
    });

    postForm?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = Object.fromEntries(new FormData(postForm).entries());
      try {
        await api('api/admin/precos/post', { method: 'POST', body: JSON.stringify(fd) });
        toast('painel de preços postado ✦');
      } catch (err) { toast(err.message, true); }
    });
  }

  // ---------- SORTEIOS ----------
  async function carregarSorteios() {
    const wrap = $('#giveaways-list');
    if (!wrap) return;
    try {
      const lista = await api('api/admin/sorteios');
      if (lista.length === 0) {
        wrap.innerHTML = '<p class="empty-copy">nenhum sorteio cadastrado.</p>';
        return;
      }
      wrap.innerHTML = lista
        .map((s) => {
          const status = s.status === 'ativo' ? '🟢 ativo' : '⚫ encerrado';
          const ganhadores = (s.ganhadores ?? []).map((id) => `<@${id}>`).join(', ');
          return `
            <article class="log-item">
              <div class="log-item__top">
                <strong>${escapeHtml(s.premio)}</strong>
                <span>${status}</span>
              </div>
              <p>id: <code>${s.id}</code> · canal: <#${s.channelId}> · ${s.participantes.length} participantes · ${s.vencedores} ganhador(es)</p>
              ${s.status === 'encerrado' && ganhadores ? `<p>vencedores: ${ganhadores}</p>` : ''}
              <div class="log-item__meta">
                <span>termina: ${new Date(s.termina).toLocaleString()}</span>
                <span>
                  ${s.status === 'ativo' ? `<button class="btn btn--outline" data-action="end" data-id="${s.id}">Finalizar agora</button>` : ''}
                  <button class="btn btn--ghost" data-action="del" data-id="${s.id}">Apagar</button>
                </span>
              </div>
            </article>`;
        })
        .join('');

      wrap.querySelectorAll('button[data-action]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const { action, id } = btn.dataset;
          try {
            if (action === 'end') {
              await api(`api/admin/sorteios/${id}/finalizar`, { method: 'POST' });
              toast('sorteio finalizado ✦');
            }
            if (action === 'del') {
              if (!confirm('apagar esse sorteio do registro?')) return;
              await api(`api/admin/sorteios/${id}`, { method: 'DELETE' });
              toast('sorteio removido');
            }
            carregarSorteios();
          } catch (err) { toast(err.message, true); }
        });
      });
    } catch (err) {
      console.warn('[sorteios]', err);
    }
  }

  function setupSorteios() {
    const form = $('#giveaway-form');
    const refresh = $('#refresh-giveaways');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = Object.fromEntries(new FormData(form).entries());
      try {
        await api('api/admin/sorteios', {
          method: 'POST',
          body: JSON.stringify({
            channelId: fd.channelId,
            premio: fd.premio,
            vencedores: Number(fd.vencedores) || 1,
            duracaoMinutos: Number(fd.duracaoMinutos) || 60,
          }),
        });
        toast('sorteio criado ✦');
        form.reset();
        form.elements.vencedores.value = 1;
        form.elements.duracaoMinutos.value = 60;
        carregarSorteios();
      } catch (err) { toast(err.message, true); }
    });

    refresh?.addEventListener('click', carregarSorteios);
    carregarSorteios();
  }

  // ---------- FORUM ----------
  async function carregarForumPosts() {
    const wrap = $('#forum-list');
    if (!wrap) return;
    try {
      const lista = await api('api/admin/forum/posts');
      if (lista.length === 0) {
        wrap.innerHTML = '<p class="empty-copy">nenhum post ainda.</p>';
        return;
      }
      wrap.innerHTML = lista
        .map(
          (p) => `
            <article class="log-item">
              <div class="log-item__top">
                <strong>${escapeHtml(p.title)}</strong>
                <span><a href="${escapeHtml(p.url)}" target="_blank" rel="noopener">abrir thread →</a></span>
              </div>
              <div class="log-item__meta">
                <span>${new Date(p.createdAt).toLocaleString()}</span>
                <span>${p.actor?.username ? `por ${escapeHtml(p.actor.username)}` : ''}</span>
              </div>
            </article>`,
        )
        .join('');
    } catch (err) {
      console.warn('[forum]', err);
    }
  }

  function setupForum() {
    const form = $('#forum-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = Object.fromEntries(new FormData(form).entries());
      try {
        await api('api/admin/forum/post', { method: 'POST', body: JSON.stringify(payload) });
        toast('post enviado ✦');
        form.reset();
        carregarForumPosts();
      } catch (err) { toast(err.message, true); }
    });

    carregarForumPosts();
  }

  // ---------- bootstrap ----------
  // espera o admin-panel.js terminar (ele já popula channels), depois roda nossa lógica
  setTimeout(async () => {
    await popularSelects();
    setupVerify();
    setupPrecos();
    setupSorteios();
    setupForum();
  }, 600);
})();
